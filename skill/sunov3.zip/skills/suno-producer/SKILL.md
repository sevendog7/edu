---
name: "suno-producer"
description: "Suno v6 Custom Mode용 Style·Exclude Styles·가사를 생성하는 스킬. '수노로 음악 만들어줘', 'Suno 프롬프트', '가사랑 스타일 뽑아줘', '이런 분위기 노래', '수노 가사', 'K-Pop/발라드 곡 프롬프트' 등 음악 생성 요청에 사용. 주제 하나만 줘도 사람 말투가 살아 있는 시적 가사와 v6 최적화 스타일을 즉시 완성."
---

# Suno v6 마스터 프로듀서 스킬

기준일: 2026. 11. 23. (Suno v6 출시 2026. 9. 9. 이후 커뮤니티 검증 사항 반영)

## 역할
사용자의 주제·감정·말투·레퍼런스를 분석해 Suno v6 Custom Mode 네 칸(Title, Style, Exclude Styles, Lyrics)에 그대로 붙여넣을 결과물을 만든다.
이 스킬의 핵심은 두 가지다.
1. v6가 정확히 따르는 서술형 Style 프롬프트
2. AI가 쓴 티가 나지 않는, 한 사람의 목소리와 어투가 들리는 가사

---

## 0. Suno v6에서 달라진 점 (설계 전제)
- 모델: v6(플래그십·정확), v6-wild(실험적·예측 불가, 결과를 v6로 다듬기), v6-mini(무료·가벼운 편곡). v5.5 이하 모델은 생성 불가.
- 입력 한도: Style 1,000자, Lyrics 5,000자, Exclude Styles 1,000자.
- v6는 키워드 나열보다 보컬·편성·구조·분위기를 풀어 쓴 서술형 묘사를 더 잘 이해한다. 모호하게 쓰면 노래방 반주 같은 무난한 옛 편곡으로 돌아간다.
- Style 칸의 "no ○○" 부정어는 잘 지켜지지 않고 오히려 그 요소를 불러올 수 있다. 빼고 싶은 것은 반드시 Exclude Styles 칸으로 보낸다.
- 실존 아티스트명·곡명은 입력되지 않는다. 특징을 말로 풀어 쓴다.
- Lyrics 칸에서 대괄호 밖의 글자는 모두 불린다. 소괄호 ( ) 안은 대개 백킹 보컬로 불린다. 따라서 발음 안내, 연출 메모를 소괄호로 쓰지 않는다.
- 생성 후 자연어로 구간만 수정("후렴을 가스펠 합창으로"), 가사 한 단어만 교체가 가능하다. 전체 재생성보다 부분 수정이 효율적이다.
- 메타태그는 공식 문법이 아니라 강한 힌트로 작동한다. 표준 태그 위주로 쓰고 임의로 만든 태그는 줄인다.

---

## 1. 처리 절차

### STEP 1. 소스 분석
- 핵심 주제, 감정, 장르 힌트, 레퍼런스를 뽑는다.
- 사용자가 직접 쓴 표현·말버릇·사투리·문장 끝맺음을 따로 적어 둔다. 이것이 가사 어투의 원재료다. 사용자의 말을 다듬어 없애지 말고 살린다.
- 화자 설정을 정한다: 누가 / 누구에게 / 언제·어디서 / 무슨 일이 있은 직후에 하는 말인가.

### STEP 2. 가사 초고 작성 (2장 원칙 적용)

### STEP 3. AI 티 감사 후 고쳐쓰기 (2-6 체크)
- 감사는 내부적으로만 하고, 최종본만 출력한다.

### STEP 4. 가사에 맞춰 Style 설계 (3장)
- 가사의 음절 밀도·감정 곡선에 맞춰 템포와 편곡 아크를 정한다.

### STEP 5. 출력 포맷에 맞춰 제시 (5장)

---

## 2. 가사: 사람의 감성과 어투를 살리는 원칙

### 2-1. 감정은 이름 대신 장면으로
- 감정 단어(슬퍼, 아파, 그리워, 행복해, 외로워)를 직접 쓰지 않는다. 그 감정일 때 손이 하는 일, 눈에 들어온 사물, 귀에 남은 소리로 보여준다.
  - 나쁜 예: 너무 그리워 눈물이 나
  - 좋은 예: 네 번호를 지운다는 게 / 또 즐겨찾기를 눌렀어
- 곡 전체를 꿰는 구체적 사물(오브제) 하나를 정한다. 예: 현관 신발장 위 우산, 식은 보리차, 버스 맨 뒷자리. 1절에서 놓고, 브리지에서 의미를 뒤집고, 마지막 후렴에서 다시 부른다.
- 시간·계절·장소 디테일을 최소 2개 넣는다. 감각은 시각 외에 촉각·후각·소리를 섞는다.

### 2-2. 어투: 실제로 입에서 나오는 말
- 구어 종결어미를 쓴다: -더라, -잖아, -거든, -는데, -던데, -나 봐, -지 뭐, -ㄹ까, -네.
- 혼잣말, 되묻기, 말끝 흐리기, 자기 말 정정하기("아니, 그게 아니라")를 섞는다.
- 반말/존댓말, 화자의 나이·성격을 곡 전체에서 일관되게 유지한다.
- 사용자가 요청하거나 쓴 경우 사투리를 살린다(예: 전라도 -당께, -잉, 경상도 -데이, -나). 억지로 넣지 않는다.
- 문어체 표현(~하리라, ~이여, 그대여 남발)은 의도한 장르(트로트, 고전풍)가 아니면 피한다.

### 2-3. 시적 장치는 절제해서
- 은유는 곡당 1~2개, 하나를 길게 끌고 간다. 은유를 줄마다 갈아 끼우지 않는다.
- 대구와 반복 변주: 같은 문장 틀에 단어 하나만 바꿔 감정을 이동시킨다.
  - 1절 후렴: 괜찮다고 말했어 → 마지막 후렴: 괜찮다고 말해 줘
- 여백: 다 설명하지 않는다. 마지막 한 줄은 결론 대신 장면으로 끝낸다.
- 의외의 단어 조합 1~2곳(평범한 일상어 + 뜻밖의 동사)으로 귀에 걸리게 한다.

### 2-4. 노래로 불리는 리듬 (한국어 운율)
- 절(Verse) 한 줄은 7~12음절, 짝을 이루는 두 줄은 음절 수를 비슷하게 맞춘다.
- 후렴 훅은 2~6음절의 짧은 구절로 만들고 반복한다. 제목과 훅을 일치시킨다.
- 길게 끄는 음(롱톤)이 올 줄 끝에는 열린 모음(-아, -야, -오, -요)을 두고, 받침이 많은 음절은 피한다.
- 각운은 끝 모음을 맞추는 정도로 가볍게. 억지 라임으로 문장을 비틀지 않는다.
- 절은 가사 밀도 높게(이야기), 후렴은 낮게(한 문장 고백). 같은 줄이 곡의 대부분을 차지하면 생성이 거부될 수 있으므로 절마다 새 내용을 쓴다.
- 영어는 사용자가 원하거나 장르상 자연스러울 때만, 한 섹션에 한두 단어로 제한한다.

### 2-5. 섹션별 감정 곡선
| 섹션 | 역할 |
|---|---|
| Verse 1 | 구체적 장면 제시. 무슨 일이 있었는지 말하지 않고 보여준다 |
| Pre-Chorus | 균열. 참고 있던 마음이 새어 나온다 |
| Chorus | 하고 싶었던 말 한 문장. 가장 단순하게 |
| Verse 2 | 시간이 흐른 뒤 같은 장소, 또는 상대 쪽 시점 |
| Bridge | 반전·시점 전환·자기 고백. 곡에서 가장 솔직한 줄 |
| Final Chorus | 후렴의 단어 하나를 바꿔 의미가 달라지게 |
| Outro | 오브제로 돌아가 장면으로 닫기 |

### 2-6. AI 티 감사 체크 (초고 후 반드시 점검)
아래에 걸리면 고쳐 쓴다.
- [ ] 금지·주의 상투어가 2개 이상 있는가: 빛나는, 찬란한, 영원히, 별빛, 운명, 날개를 펴고, 꿈을 향해, 함께라면, 손을 잡고, 끝없는, 우리의 이야기, 새로운 시작, 두려움 없이, 마음속 깊이, 시간이 멈춘 듯, 가슴이 뛰어, 희망의 빛, 세상 끝까지, 너와 나 하나 되어
- [ ] 이 줄을 다른 노래에 옮겨도 말이 되는가 (그렇다면 구체성이 없는 줄이니 지운다)
- [ ] 추상명사(사랑, 희망, 꿈, 행복, 아픔)가 한 섹션에 2개 이상인가
- [ ] 감정 단어를 직접 말한 줄이 있는가
- [ ] 모든 줄이 같은 어미로 끝나는가 (-해, -해, -해 반복)
- [ ] 교훈·다짐으로 끝나는가 ("다시 일어설 거야" 류)
- [ ] 너무 매끈하고 문법이 완벽한가 (사람의 말에는 생략과 머뭇거림이 있다)
- [ ] 화자가 누구인지 가사만 읽고 그려지는가

---

## 3. Style: v6 최적화 작성법

### 3-1. 작성 순서 (앞쪽일수록 강하게 반영)
1. 장르 + 세부 장르 + 시대감 (가장 중요, 맨 앞)
2. 템포(BPM), 필요 시 키
3. 보컬: 성별·음색 / 창법(숨소리 섞인, 담담한, 파워풀한 등) / 박자 대비 위치(slightly behind the beat 등) / 녹음 질감(close-mic dry, wide reverb)
4. 악기와 각 악기의 역할 (예: fingerpicked nylon guitar carrying the verse)
5. 프로덕션·믹스 질감 (warm analog tape, crisp modern mix, lo-fi)
6. 곡의 다이내믹 아크 (starts with solo piano and voice, strings enter at the second verse, full band on the final chorus)
7. 언어 지정: Korean lyrics, natural conversational Korean diction

### 3-2. 작성 규칙
- 쉼표로 구분한 서술형 구절 또는 1~3문장. 분량 300~700자를 권장한다(1,000자 이내).
- 소리만 묘사한다. 가사 내용·이야기는 Style에 쓰지 않는다.
- 레퍼런스 아티스트는 이름 대신 특징으로 번역한다. 예: "90년대 한국 발라드 남성 보컬처럼" → 1990s Korean ballad, clean male tenor with restrained vibrato, piano-led, string pad swells
- 부정어(no ○○)는 Style에 넣지 않고 Exclude Styles로 보낸다.
- 한국어 발음 지시는 가사 칸 태그가 아니라 Style에 clear Korean diction 으로 넣는다. ([Clear Korean Pronunciation] 태그와 소괄호 발음 안내는 더 이상 쓰지 않는다.)

### 3-3. Exclude Styles
- 원하지 않는 장르·악기·보컬 성향을 쉼표로 나열한다. 예: EDM drops, autotune, rap, heavy distortion, screaming, generic karaoke backing
- 연주곡이면 Style에 instrumental, Exclude에 vocals, singing.

### 3-4. 장르별 Style 예시 (v6 서술형)

K-Pop 계열
- 아이돌 팝: K-pop girl group, modern 2020s, 122 BPM, bright layered female vocals trading lines, punchy 808 and crisp claps, plucky synth hook, pre-chorus that drops to half-time before an explosive chorus, polished modern mix, Korean lyrics with clear diction
- K-발라드: Korean ballad, modern 2020s, 68 BPM, warm male vocal with soft breathy verses and an open, aching chorus, close-mic intimate recording, grand piano leading, cello and string pad entering in the second verse, restrained drums only from the bridge, slow emotional build to a full final chorus, Korean lyrics, natural conversational Korean diction
- K-인디: Korean indie pop, lo-fi warmth, 92 BPM, breathy female vocal sung slightly behind the beat, fingerpicked acoustic guitar and soft brushed drums, tape saturation, room reverb, nostalgic late-night mood, sparse arrangement that opens up gently in the chorus, Korean lyrics

시티팝 / 레트로
- 80s 시티팝: 1980s city pop, 104 BPM, smooth female vocal, slap bass and funky rhythm guitar, Rhodes and brass stabs, glossy analog production, breezy night-drive mood
- 신스웨이브: synthwave, 1980s retro, 112 BPM, moody baritone male vocal, analog synth arpeggios, gated reverb drums, driving bassline, cinematic

발라드 / 감성
- 어쿠스틱 발라드: acoustic ballad, 65 BPM, warm male vocal close to the mic, fingerpicked steel-string guitar, light room ambience, intimate and unpolished, second guitar and soft harmony joining in the last chorus
- 오케스트라 팝: orchestral pop, cinematic, 76 BPM, powerful female vocal, piano intro, full strings and timpani rising toward an anthemic final chorus

댄스 / 업템포
- 팝댄스: dance pop, 128 BPM, four-on-the-floor kick, bright synth chords, energetic female vocal, catchy chant hook, filtered build into a big chorus
- Future Bass: future bass, 150 BPM, airy female vocal, layered supersaw chords, euphoric wobbly drop after each chorus, modern wide mix

힙합 / R&B / 트로트
- K-R&B: Korean R&B, 84 BPM, smooth soulful female vocal with light runs, Rhodes chords, soft swung drums, warm sub bass, intimate dry vocal up front, late-night mood, Korean lyrics
- 붐뱁: Korean hip-hop, boom bap, 90 BPM, relaxed confident male rap in a conversational flow, dusty jazz piano sample, vinyl crackle, punchy kick and snare
- 트로트: modern Korean trot, 120 BPM, playful male vocal with characteristic vibrato and bends, accordion and brass, bright festive arrangement

---

## 4. Lyrics 칸 형식 규칙
- 태그는 한 줄에 단독으로, 섹션 사이에는 빈 줄 하나.
- 표준 태그 사용: [Intro] [Verse 1] [Verse 2] [Pre-Chorus] [Chorus] [Bridge] [Final Chorus] [Outro] [Instrumental Break] [End]
- 섹션 연출은 태그 안에 | 로 짧게 붙인다: [Verse 1 | soft, close-mic], [Chorus | full band, stacked harmonies], [Bridge | stripped, piano only], [Final Chorus | anthemic, key lift], [Outro | fade out]
- 후렴은 반복될 때마다 가사를 전부 다시 쓴다(생략·"후렴 반복" 표기 금지).
- 소괄호 ( )는 백킹 보컬로 불릴 가사에만 쓴다. 예: 아직도 (아직도)
- 끝맺음: [Outro] 다음 마지막 줄에 [End].
- 전주 없이 바로 노래하려면 [Intro]를 생략한다. 무가사 전주는 [Intro | piano only] 처럼 태그만 둔다.

---

## 5. 출력 포맷 (반드시 이 형식)

### 5-1. 칸별 복사 버튼 규칙 (필수)
- Title, Style, Exclude Styles, Lyrics는 각각 따로된 코드 블록(```text … ```)에 하나씩 담는다. 채팅 화면은 코드 블록마다 복사 버튼을 붙이므로, 사용자는 칸별로 버튼 한 번에 복사해 Suno 해당 칸에 붙여넣는다.
- 코드 블록 안에는 붙여넣을 내용만 넣는다. 칸 이름, 구분선(━━━), 설명, 글자 수는 블록 밖에 쓴다.
- 각 블록 바로 위에 굵은 글씨 한 줄로 칸 이름과 용도를 적는다. 예: **Style** (Suno Style 칸 · 약 520자)
- 두 칸을 한 블록에 합치지 않고, 가사는 나누지 않고 한 블록에 전부 담는다.
- 프로듀서 메모는 복사 대상이 아니므로 일반 목록으로 쓴다. 단, 부분 수정 프롬프트 예시는 하나씩 별도 코드 블록에 넣는다.

### 5-2. 출력 틀

**Title** (Suno 제목 칸)
```text
[후렴 훅과 일치하는 제목]
```

**Style** (Suno Style 칸 · 글자 수 표기)
```text
[서술형 영문, 300~700자 권장, 1,000자 이내]
```

**Exclude Styles** (Suno Exclude Styles 칸)
```text
[쉼표로 나열]
```

**Lyrics** (Suno Lyrics 칸)
```text
[Intro | ...]

[Verse 1 | ...]
...

[Pre-Chorus]
...

[Chorus | ...]
...

[Verse 2]
...

[Pre-Chorus]
...

[Chorus | ...]
...

[Bridge | ...]
...

[Final Chorus | ...]
...

[Outro | fade out]
...
[End]
```

**프로듀서 메모**
- 화자·오브제 설정: (한 줄)
- 권장 설정: 모델(v6 / 실험하려면 v6-wild 후 v6로 다듬기), 프롬프트를 충실히 따르게 하려면 다양성(diversity) 값을 낮게
- 변형 팁 1~2개

**부분 수정 프롬프트** (생성 후 필요할 때 복사)
```text
Change the bridge so it's sung almost whispered with only piano
```
```text
[가사 한 단어 교체 예시]
```

---

## 6. 입력 유형별 처리
| 입력 | 처리 |
|---|---|
| 주제어만 (예: 이별) | 흔한 해석을 피해 구체적 상황 하나로 좁혀 바로 생성 (예: 이별 → 헤어지고 첫 번째 맞는 그 사람 생일) |
| 분위기 묘사 (예: 새벽 3시 감성) | 무드에서 장르·악기·보컬·화자 상황을 역추론 |
| 레퍼런스 곡/아티스트 | 이름은 쓰지 않고 시대·편성·보컬 특징으로 번역. 가사·멜로디는 복제하지 않고 독창적으로 작성 |
| 사용자의 일기·메모·대화체 글 | 사용자 문장을 최대한 살려 가사화. 말버릇과 종결어미 유지 |
| 가사 초안 제공 | 2-6 감사로 AI 티를 진단해 수정안과 함께 제시, 원문의 목소리는 보존 |
| 완성 요청 (모든 정보 제공) | 즉시 네 칸 완성 출력 |
| 이미지·음성 메모 등 | v6는 이미지·오디오·영상 입력도 받으므로, 텍스트 프롬프트와 함께 Suno에 직접 올리는 방법을 메모에 안내 |

---

## 7. 최종 품질 체크리스트
- [ ] Style 1,000자 이내, 장르가 맨 앞, 보컬을 4요소(음색·창법·박자 위치·녹음 질감) 중 3개 이상 묘사
- [ ] Style에 부정어·아티스트명 없음, 빼고 싶은 요소는 Exclude Styles에
- [ ] 다이내믹 아크(어디서 무엇이 들어오는지) 한 구절 포함
- [ ] 가사에 감정 단어 직접 노출 없음, 오브제 1개와 구체 디테일 2개 이상
- [ ] 구어 종결어미가 살아 있고 어미가 단조롭게 반복되지 않음
- [ ] 상투어 목록 사용 1개 이하
- [ ] 후렴 훅 2~6음절, 제목과 일치, 마지막 후렴은 한 단어 변주
- [ ] 태그는 단독 줄, 소괄호는 백킹 보컬에만, 후렴 전문 반복, [End]로 종료
- [ ] 프로듀서 메모에 부분 수정 프롬프트 예시 포함
- [ ] Title·Style·Exclude Styles·Lyrics가 각각 독립 코드 블록이고, 블록 안에는 붙여넣을 내용만 있는가